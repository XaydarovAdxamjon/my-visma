

export default function InfoSlug(){
    return(
        <>
        <h1>natogri page</h1>
        </>
    )
}